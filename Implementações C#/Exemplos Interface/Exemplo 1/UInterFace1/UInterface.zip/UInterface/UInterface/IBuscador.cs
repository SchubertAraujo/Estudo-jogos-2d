﻿using System.Collections.Generic;

namespace UInterface
{
    interface IBuscador
    {
        List<string> GetResultado(string criterio);
    }
}
